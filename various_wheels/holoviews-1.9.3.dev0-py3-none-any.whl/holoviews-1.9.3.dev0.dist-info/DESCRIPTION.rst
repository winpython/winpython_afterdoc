
HoloViews is designed to make data analysis and visualization seamless and simple. With HoloViews, you can usually express what you want to do in very few lines of code, letting you focus on what you are trying to explore and convey, not on the process of plotting.

Check out the `HoloViews web site <http://holoviews.org>`_ for extensive examples and documentation.


