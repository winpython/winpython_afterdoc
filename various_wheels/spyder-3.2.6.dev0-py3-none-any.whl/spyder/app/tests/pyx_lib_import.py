import pyx_script

b = pyx_script.factorial(10)
