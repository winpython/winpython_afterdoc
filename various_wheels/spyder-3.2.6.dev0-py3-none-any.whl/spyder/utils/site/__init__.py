# -*- coding: utf-8 -*-
#
# Copyright © Spyder Project Contributors
# Licensed under the terms of the MIT License
# (see spyder/__init__.py for details)

"""
spyder.utils.site
=================

Site packages for Spyder consoles

NOTE: This package shouldn't be imported at **any** place.
      It's only used to set additional functionality for
      our consoles.
"""
